package MicroBlog1;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.Arrays;

public class Main {

    public static void main(String[] args){

        User[] stuff = new User[3];
       

            stuff[0] = new User("donquijote.org","DeLaMancha", "Don", "Quijote","dq@yahoo.com");
            stuff[1] = new User("RabbitHole.com","BunnyHop",  "Easter" , "Bunny", "basketofeggs@gmail.com");
            stuff[2] = new User("PumpkinPatch.com", "OneandOnly", "Great", "Pumpkin", "WaitingforGodot.com");
           
        

            for(int j=0; j<stuff.length; j++){
                System.out.println(stuff[j].getUrl());
                System.out.println(stuff[j].getuserName());
                System.out.println(stuff[j].getfirstName()+" "+stuff[j].getlastName());
                System.out.println(stuff[j].getemail()+"\n");

            }

            Post[] talk = new Post[5];
           

                talk[0] = new Post("DeLaMancha",1,"I found the monster!!", "donquijote.org");
                talk[1] = new Post("BunnyHop",2, "Here comes Peter Cottontail hopping down the bunny trail", "basketofeggs@gmail.com");
                talk[2] = new Post("OneandOnly",3, "Wait in the pumpkin patch, when the moon is full", "WaitingforGodot.com");
                talk[3] = new Post("DeLaMancha",4, "It was a windmill :(", "donquijote.org");
                talk[4] = new Post("OneandOnly",5, "The Great Pumpkin is here!", "WaitingforGodot.com");
                

                for (int m=0; m<talk.length;m++){

                    System.out.println(talk[m].getuserName());
                    System.out.println(talk[m].getpost());
                    System.out.println("Post #: " + talk[m].getorderNumber()+ "\n\n");
                    

                }
            }
        }
    


