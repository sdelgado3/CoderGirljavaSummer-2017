package MicroBlog1;

public class User{
    private String url;
    private String userName;
    private String firstName;
    private String lastName; 
    private String email;

    
  

    public User(String url, String userName, String firstName, String lastName, String email )
    {
        this.url = url;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public String getuserName()
    {
        return this.userName;

    }

    public String getfirstName(){

        return this.firstName;

    }

    public String getlastName()
    {
        return this.lastName;
    }  

    public String getUrl()
    {
        return this.url;
    }

    public String getemail()
    {
        return this.email;
    }

}
