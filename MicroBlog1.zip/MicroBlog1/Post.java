package MicroBlog1;

public class Post{

    private String userName; 
    private int orderNumber; 
    private String post;
    private String webAddress; 

    public Post(String userName, int orderNumber, String post, String webAddress )
    {
        this.userName = userName;
        this.orderNumber = orderNumber;
        this.post = post;
        this.webAddress = webAddress;
        
    }

    public String getuserName()
    {
        return this.userName;

    }

    public int getorderNumber(){

        return this.orderNumber;

    }

    public String getpost()
    {
        return this.post;
    }  

    public String getwebAddress()
    {
        return this.webAddress;
    }

   
}