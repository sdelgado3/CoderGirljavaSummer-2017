package Microblog3;

public class Post{

    private String userName; 
    private int orderNumber; 
    private String post;
    private String webAddress; 

    public Post(String userName, int orderNumber, String post, String webAddress )
    {
        this.userName = userName;
        this.orderNumber = orderNumber;
        this.post = post;
        this.webAddress = webAddress;
        
    }

    public String getUserName()
    {
        return this.userName;

    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public int getOrderNumber(){

        return this.orderNumber;

    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getPost()

    {
        return this.post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getWebAddress()

    {
        return this.webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }
}