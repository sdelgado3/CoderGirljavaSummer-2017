package Microblog3;


import static java.lang.System.out;
import  java.util.Scanner;
import java.util.ArrayList;

public class Main2 {

    //static ArrayList<User> userList = new ArrayList<User>();


    public static void main(String[] args) {

        TheMenu();
        //User currentUser;
    }

    public static void TheMenu() {
        // String Customer[] = new String[10];
        Scanner kbd = new Scanner(System.in);
        String mainMenu = ("Select a choice from the menu: \n"
                + "1. Create a new user\n"
                + "2. Become an existing user\n"
                + "3. Create a post as the current user\n"
                + "4. Print all posts\n"
                + "5. Print all users\n"
                + "6. Exit");

        System.out.println(mainMenu);

        int menuChoice = kbd.nextInt();

        ArrayList<User> ul = new ArrayList<>();

        User u1 = new User("donquijote.org", "DeLaMancha", "Don", "Quijote", "dq@yahoo.com");
        User u2 = new User("RabbitHole.com", "BunnyHop", "Easter", "Bunny", "basketofeggs@gmail.com");
        User u3 = new User("PumpkinPatch.com", "OneandOnly", "Great", "Pumpkin", "WaitingforGodot.com");

        ul.add(u1);
        ul.add(u2);
        ul.add(u3);

        Post p1 = new Post("DeLaMancha", 1, "I found the monster!!", "donquijote.org");
        Post p2 = new Post("BunnyHop", 2, "Here comes Peter Cottontail hopping down the bunny trail", "basketofeggs@gmail.com");
        Post p3 = new Post("OneandOnly", 3, "Wait in the pumpkin patch, when the moon is full", "WaitingforGodot.com");
        Post p4 = new Post("DeLaMancha", 4, "It was a windmill :(", "donquijote.org");
        Post p5 = new Post("OneandOnly", 5, "The Great Pumpkin is here!", "WaitingforGodot.com");

        ArrayList<Post> pl = new ArrayList<>();

        pl.add(p1);
        pl.add(p2);
        pl.add(p3);
        pl.add(p4);
        pl.add(p5);

        while (menuChoice < 1 || menuChoice > 6) {
            System.out.print("\nError! Incorrect choice.\n");
            System.out.println(mainMenu);
            menuChoice = kbd.nextInt();

        }
        while (menuChoice != 6) {

            if (menuChoice == 1)

            {
                out.print("Enter your user name:");
                String userName = kbd.next();
                out.print("Please enter URL:");
                String url = kbd.next();
                out.print("Please enter first name:");
                String firstName = kbd.next();
                out.print("Please enter last name:");
                String lastName = kbd.next();
                out.print("Please enter email:");
                String email = kbd.next();

                u1 = new User(url, userName, firstName, lastName, email);
                ul.add(u1);


            }
            if (menuChoice == 2) {

                for (int x = 0; x < ul.size(); x++) {
                    int y = x + 1;
                    out.println(y + "." + ul.get(x).getUserName());
                }
                int choice = kbd.nextInt();
                User CurrentUser = (ul.get(choice - 1));
                out.println("You are currently user " + CurrentUser.getUserName()  +". What would you like to do?");


            }
            if (menuChoice == 3) {

                out.print("Enter your user name:");
                String userName = kbd.next();
                out.print("Please enter order number:");
                int orderNumber = kbd.nextInt();
                out.print("Please enter post:");
                String post = kbd.next();
                out.print("Please enter url:");
                String url = kbd.next();

                p1 = new Post(userName, orderNumber, post, url);
                pl.add(p1);


                for (int x = 0; x < pl.size(); x++) {
                    int y = x + 1;
                    out.println(y + "." + pl.get(x).getPost());
                }
            }
                if (menuChoice == 4) {
                    for (int x = 0; x < pl.size(); x++) {
                        int y = x + 1;
                        out.println(y + "." + pl.get(x).getPost());
                    }
                    }
                    if (menuChoice == 5) {
                        for (int x = 0; x < ul.size(); x++) {
                            int y = x + 1;
                            out.println(y + "." + ul.get(x).getUserName());
                        }
                    }
                        if (menuChoice == 6) {
                            break;
                        }


            out.println(mainMenu);

            menuChoice = kbd.nextInt();
        }

    }
}












