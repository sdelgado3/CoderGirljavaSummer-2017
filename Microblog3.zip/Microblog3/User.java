package Microblog3;



public class User {
    private String url;
    private String userName;
    private String firstName;
    private String lastName;
    private String email;


    public User(String url, String userName, String firstName, String lastName, String email) {
        this.url = url;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;


    }

    public String getUserName() {
        return this.userName;

    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {

        return this.firstName;

    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName()

    {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUrl()

    {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEmail()

    {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }




}

